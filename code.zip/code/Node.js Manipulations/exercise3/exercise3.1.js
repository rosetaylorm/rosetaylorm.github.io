//Julia Hogroian & Taylor Rose, PS6, Due Monday, April 7, R03, Kelly
var http = require('http');
var port = 8000;
http.createServer(function(req, res) {
    var statusList = [{
		"name"		: "Many Hands Organic Farm",
		"latitude"	: "42.422115",
		"longitude"	: "-72.158165",
		"inventory"	: {"DairyEggs":{"eggs":"1111"}}
		},{
		"name"		: "River Valley Farm",
		"latitude"	: "42.393658",
		"longitude"	: "-73.238785",
		"inventory"	: {"DairyEggs":{"eggs":"1111"}}
		},{
		"name"		: "Seaweed & Codfish Herb Farm",
		"latitude"	: "41.65991",
		"longitude"	: "-70.17267",
		"inventory"	: {"DairyEggs":{"eggs":"1111"}}
	}];

    console.log(req);
    console.log(JSON.stringify(statusList));
    res.writeHead(200, {'content-type': 'application/json'});
    res.write(JSON.stringify(statusList, 0, 4));
    res.end();
}).listen(port);

console.log('server listening on port 8000');