//Julia Hogroian & Taylor Rose, PS6, Due Monday, April 7, R03, Kelly
	function setItems() 
	{ 
		// on category selection, populate items
		var category = document.getElementById('category');
		var items = SelectItems(category.value);
		var item = document.getElementById('item');
		item.options.length=0;

		for (i=0; i<items.length; i++){
			item.options[i]=new Option(items[i], items[i], true, false);
		}
	}

	function Search()
	{
		// on search event, build filename and call load data function
		var category = document.getElementById('category').value;
		var item = document.getElementById('item').value;
		var season = document.getElementById('season').value;
		season = seasonCode();
		var query = 'inventory.' + category + '.' + item;
		LoadJsonData(query, season);
		//showQueryResults(farms);
	}

	function seasonCode(season){
		return '0011';
	}

	// CALL SEARCH FIRST

	function LoadJsonData(query, season)
	{
		var url = 'http://localhost:8000/?query=' + query + '&season=' + season;
		//var url = 'http://localhost:8000/?query=inventory.Vegetables.beets&season=0011';
		// make xhr request
		var xhReq = new XMLHttpRequest();
		xhReq.open("GET", url, false);
		xhReq.send(null);
		var serverResponse = xhReq.responseText;
		console.log(serverResponse); 
		var farms = JSON.parse(serverResponse); 
		var length = farms.length;
		for (var i = 0; i < length; i++) {
			console.log(farms[i].name);
		}
		console.log('for debugging');

	}

	
	function SelectItems(category)
	{
		var itemsArray;
		switch(category)
		{
			case "fruits":
			  return fruits;
			  break;
			case "vegetables":
			  return vegetables;
			  break;
			case "meatsLivestock":
			  return meatsLivestock;
			  break;
			case "dairyEggs":
			  return dairyEggs;
			  break;
			case "fibers":
			  return fibers;
			  break;
			case "flowers":
			  return flowers;
			  break;
			case "grains":
			  return grains;
			  break;
			case "herbs":
			  return herbs;
			  break;
			case "nutsSeeds":
			  return nutsSeeds;
			  break;
			case "processed":
			  return processed;
			  break;
			case "specialtyProducts":
			  return specialtyProducts;
			  break;
			case "sprouts":
			  return sprouts;
			  break;
			default:
			  return vegetables;
		}
	}


	function initializeSearchFields(){
		// initialize categories and select vegetables as default
		var category = document.getElementById('category');
		for (i=0; i<categories.length; i++){
			if (categories[i] == 'vegetables')
			{
				category.options[i]=new Option(categories[i], categories[i], false, true);
			}
			else
			{
				category.options[i]=new Option(categories[i], categories[i], false, false);
			}
		}

		// initialize with vegetable items
		var item = document.getElementById('item');
		for (i=0; i<vegetables.length; i++){
			item.options[i]=new Option(vegetables[i], vegetables[i], true, false);

			if (vegetables[i] == 'radish')
			{
				item.options[i]=new Option(vegetables[i], vegetables[i], false, true);
			}
			else
			{
				item.options[i]=new Option(vegetables[i], vegetables[i], false, false);
			}

		}

		// populate the seasons
		var season = document.getElementById('season');
		for (i=0; i<seasons.length; i++){

			if (seasons[i] == 'summer')
			{
				season.options[i]=new Option(seasons[i], seasons[i], false, true);
			}
			else
			{
				season.options[i]=new Option(seasons[i], seasons[i], false, false);
			}
		}

	}