//Julia Hogroian & Taylor Rose, PS6, Due Monday, April 7, R03, Kelly
function callServer(){
	var url = 'http://localhost:8000/?latitude=41.65991';

	// make xhr http
	var xhReq = new XMLHttpRequest();
	xhReq.open('GET', url, false);
	xhReq.send("");
	var serverResponse = xhReq.responseText;

	// create object from response
	var obj = JSON.parse(serverResponse);
	console.log(obj.name);
}