//Julia Hogroian & Taylor Rose, PS6, Due Monday, April 7, R03, Kelly
var http = require('http');
var url = require('url');
var MongoClient = require('mongodb').MongoClient;
var format = require('util').format;

var address = 'mongodb://127.0.0.1:27017/test';

var response = null;

findContent(response);

/* var server = http.createServer(function(request, response) {
    console.log("Server writing head");
    response.writeHead(200, {'content-type': 'text/plain'});
    findContent(response);
}); */

function findContent(response) {

  console.log("Server finding content");

  MongoClient.connect(address, function(err, db) {

    if (err) {
        console.log(err.text);
        throw err;
    }

    console.log("DB connected");

    var collection = db
      .collection('formTest')
      .find()
      .toArray(function(err, docs) {

        var keys = {};
        for (var i = 0; i < docs.length; i++) {
            for (var k in docs[i].inventory[0]) {
                keys[k] = keys[k] == null ? 1 : keys[k] + 1;
            }
        }
        console.log(keys);

        //process.exit(0);
        // response.write(results + '\n');
        // for(var doc in docs[0]){
        //     console.log(doc);
        //     console.dir(doc);
        //     if(doc.inventory){
        //         results = JSON.stringify(Object.keys(doc.inventory[0]));
        //     }
        //     response.write(results + '\n');
        // }
        // response.end('ran to end\n');
      });


    // for (var farm in collection) {
    // response.write(JSON.stringify(farm.inventory));
    // response.end();
    // console.dir(JSON.stringify(farm.inventory));
    // };
  });
}

/* server.listen(8000);
server.setTimeout(100);
console.log('Server running at http://localhost:8000'); */
